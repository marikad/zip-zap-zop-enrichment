<div class="span3 pm-sidebar pm-sidebar-dual">
	<aside>
    	<?php if ( !function_exists( 'dynamic_sidebar' ) || !dynamic_sidebar('blog_page_left_column_widget') ) : ?>
    	<?php endif; ?>
    </aside>
</div><!-- /sidebar -->