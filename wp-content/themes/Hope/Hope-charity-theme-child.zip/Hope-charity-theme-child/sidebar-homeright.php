<div class="span3 pm-sidebar">
	<aside>
    	<?php if ( !function_exists( 'dynamic_sidebar' ) || !dynamic_sidebar('home_right_column_widget') ) : ?>
    	<?php endif; ?>
    </aside>
</div><!-- /sidebar -->