<div class="pm_searchbar_container widget">
                                
    <div class="pm_search_field_container widget" id="pm_search_field_widget">
      <form action="<?php echo home_url( '/' ); ?>" method="get" id="searchform-widget">
          <input type="text" name="s" id="s" maxlength="100" class="pm_searchfield" placeholder="<?php esc_attr_e('Type Keywords...', 'localization') ?>">                                      
          <a href="#" class="searchBtn searchsubmit" id="searchsubmit-widget"><i class="fa fa-search"></i></a>
       </form>
    </div>
    
</div>
