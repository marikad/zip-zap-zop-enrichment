<div class="span4 pm-sidebar">
	<aside>
    	<?php if ( !function_exists( 'dynamic_sidebar' ) || !dynamic_sidebar('Woocommerce') ) : ?>
    	<?php endif; ?>
    </aside>
</div><!-- /sidebar -->